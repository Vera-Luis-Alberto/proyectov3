export interface ChoferInterface {

    cedula: string;
    nombres: string;
    apellidos: string;
    disponibilidad: string;
}