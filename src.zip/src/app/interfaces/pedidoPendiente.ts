export interface PedidoPendienteInterface {

    id: string;
    ciCliente: string;
    ciDestinatario: string;
    telefono: string;
}