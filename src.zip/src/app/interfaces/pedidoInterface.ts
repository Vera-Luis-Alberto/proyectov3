export interface PedidoInterface {

    id: string;
    cliente: string;
    costo: string;
    estado: string;
}