export interface VehiculoInterface {

    matricula: string;
    marca: string;
    disponibilidad: string;
    tipo: string;
}