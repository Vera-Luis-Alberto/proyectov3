export interface SecretariaInterface {

    cedula: string;
    nombres: string;
    apellidos: string;
}