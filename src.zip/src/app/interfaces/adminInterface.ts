export interface AdminInterface {

    cedula: string;
    nombres: string;
    apellidos: string;
}